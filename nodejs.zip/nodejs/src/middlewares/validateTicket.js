const ALLOWED = ['low', 'medium', 'high'];

function validateTicket(req, res, next) {
  const { title, priority } = req.body;

  if (!title || typeof title !== 'string') {
    return res.status(400).json({ error: 'Поле title обязательно и должно быть строкой' });
  }

  if (!priority || !ALLOWED.includes(priority)) {
    return res.status(400).json({ error: 'Поле priority должно быть low / medium / high' });
  }

  next();
}

module.exports = validateTicket;