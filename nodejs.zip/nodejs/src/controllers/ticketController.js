const service = require('../services/ticketService');

function getAll(req, res) {
  const filter = req.query.priority;
  const result = service.getAll(filter);
  res.status(200).json(result);
}

function getById(req, res, next) {
  const ticket = service.getById(req.params.id);
  if (!ticket) {
    const err = new Error('Заявка не найдена');
    err.status = 404;
    return next(err);
  }
  res.status(200).json(ticket);
}

function create(req, res) {
  const ticket = service.create(req.body);
  res.status(201).json(ticket);
}

function update(req, res, next) {
  const ticket = service.update(req.params.id, req.body);
  if (!ticket) {
    const err = new Error('Заявка не найдена');
    err.status = 404;
    return next(err);
  }
  res.status(200).json(ticket);
}

function patch(req, res, next) {
  const ticket = service.patch(req.params.id, req.body);
  if (!ticket) {
    const err = new Error('Заявка не найдена');
    err.status = 404;
    return next(err);
  }
  res.status(200).json(ticket);
}

function remove(req, res, next) {
  const ok = service.remove(req.params.id);
  if (!ok) {
    const err = new Error('Заявка не найдена');
    err.status = 404;
    return next(err);
  }
  res.status(204).send();
}

module.exports = { getAll, getById, create, update, patch, remove };