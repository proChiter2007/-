const tickets = require('./services/store');

function seed() {
  const priorities = ['high', 'medium', 'low'];
  for (let i = 1; i <= 19; i++) {
    tickets.push({
      id: i,
      title: `Заявка №${i}`,
      description: `Описание проблемы №${i}`,
      priority: priorities[i % 3],
      createdAt: new Date().toISOString(),
    });
  }
  console.log(`Seed: добавлено ${tickets.length} заявок`);
}

module.exports = seed;