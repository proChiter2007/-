const tickets = require('./store');

const priorityOrder = { high: 1, medium: 2, low: 3 };

function getAll(filterPriority) {
  let result = [...tickets];
  if (filterPriority) {
    result = result.filter(t => t.priority === filterPriority);
  }
  result.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  return result;
}

function getById(id) {
  return tickets.find(t => t.id === Number(id));
}

function create(data) {
  const newId = tickets.length ? Math.max(...tickets.map(t => t.id)) + 1 : 20;
  const ticket = {
    id: newId,
    title: data.title,
    description: data.description,
    priority: data.priority,
    createdAt: new Date().toISOString(),
  };
  tickets.push(ticket);
  return ticket;
}

function update(id, data) {
  const ticket = getById(id);
  if (!ticket) return null;
  ticket.title = data.title;
  ticket.description = data.description;
  ticket.priority = data.priority;
  return ticket;
}

function patch(id, data) {
  const ticket = getById(id);
  if (!ticket) return null;
  if (data.title) ticket.title = data.title;
  if (data.description) ticket.description = data.description;
  if (data.priority) ticket.priority = data.priority;
  return ticket;
}

function remove(id) {
  const index = tickets.findIndex(t => t.id === Number(id));
  if (index === -1) return false;
  tickets.splice(index, 1);
  return true;
}

module.exports = { getAll, getById, create, update, patch, remove };