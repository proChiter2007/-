const express = require('express');
const router = express.Router();
const controller = require('../controllers/ticketController');
const validateTicket = require('../middlewares/validateTicket');

router.get('/', controller.getAll);
router.get('/:id', controller.getById);
router.post('/', validateTicket, controller.create);
router.put('/:id', validateTicket, controller.update);
router.patch('/:id', controller.patch);
router.delete('/:id', controller.remove);

module.exports = router;